class Int1:
    def __init__(int):
        pass

class Int2:
    def __init__(int):
        pass

class Int3:
    def __init__(int):
        pass

class Int4:
    def __init__(int):
        pass

class Int5:
    def __init__(int):
        pass


class Scale:
    def __init__(int):
        pass


class Float1:
    def __init__(float):
        pass

class Float2:
    def __init__(float):
        pass

class Float3:
    def __init__(float):
        pass


class Img:
    def __init__(ndarray):
        pass
    
class Img1:
    def __init__(ndarray):
        pass
    
class Img2:
    def __init__(list):
        pass

class Img3:
    def __init__(ndarray):
        pass
    
class Vector:
    def __init__(list):
        pass

class Vector_C:
    def __init__(ndarray):
        pass


class Vector_raw:
    def __init__(list):
        pass


class Weight2:
    def __init__(ndarray):
        pass
class Weight3:
    def __init__(ndarray):
        pass

class Weight4:
    def __init__(ndarray):
        pass

class ClassLabel:
    def __init__(list):
        pass

class windowSize:
    def __init__(int):
        pass

class width:
    def __init__(int):
        pass

class height:
    def __init__(int):
        pass

class X:
    def __init__(int):
        pass

class Y:
    def __init__(int):
        pass

class s:
    def __init__(int):
        pass


class s2:
    def __init__(list):
        pass