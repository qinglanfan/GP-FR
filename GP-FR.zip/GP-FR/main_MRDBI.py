# python packages
import random
import time
import evalGP_fgp as evalGP
import gp_restrict as gp_restrict
import numpy
from deap import base, creator, tools, gp
from strongGPDataType import Int1, Int2, Int3, Float1, Float2, Img, Vector, ClassLabel, Vector_C, \
    Img1, Img2, X, Y, windowSize, width, height
import fgp_functions_new as fe_fs
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn import preprocessing
import saveFile
import pickle
import sys

# randomSeeds = 7
# dataSetName = 'jaffe'
dataSetName = str(sys.argv[1])
randomSeeds = str(sys.argv[2])

x_train = numpy.load('/nfs/scratch2/fanqing1/mycode1/' +  dataSetName + '_train_data.npy') / 255.0
y_train = numpy.load('/nfs/scratch2/fanqing1/mycode1/' +  dataSetName + '_train_label.npy')
x_test = numpy.load('/nfs/scratch2/fanqing1/mycode1/' +  dataSetName + '_test_data.npy') / 255.0
y_test = numpy.load('/nfs/scratch2/fanqing1/mycode1/' +  dataSetName + '_test_label.npy')

x_train = numpy.squeeze(x_train)
x_test = numpy.squeeze(x_test)
y_train = numpy.argmax(y_train, axis=1)
y_test = numpy.argmax(y_test, axis=1)
y_train = y_train.astype(float)
y_test = y_test.astype(float)

print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)
# parameters:
population = 250
generation = 25
cxProb = 0.8
mutProb = 0.19
elitismProb = 0.01
totalRuns = 1
initialMinDepth = 2
initialMaxDepth = 10
# maxDepth = 10
h = x_train[0].shape[0]
w = x_train[0].shape[1]
print('h', h)
print('w', w)

# GP
pset = gp.PrimitiveSetTyped('MAIN', [Img], ClassLabel, prefix='Image')

# image classification layer
pset.addPrimitive(fe_fs.classifier_selection, [Vector_C, Int3], ClassLabel, name='classifier')

# high level features--feature construction layer
pset.addPrimitive(fe_fs.feature_con2, [Vector, Vector_C], Vector_C, name='FeaturesC_dif')
pset.addPrimitive(fe_fs.feature_con, [Vector, Vector], Vector_C, name='Features2C')
pset.addPrimitive(fe_fs.feature_con, [Vector, Vector, Vector], Vector_C, name='Features3C')
pset.addPrimitive(fe_fs.feature_con, [Vector, Vector, Vector, Vector], Vector_C, name='Features4C')
# pset.addPrimitive(fe_fs.feature_con, [Vector_raw, Vector], Vector_C, name='Features')


# input is the whole raw image
pset.addPrimitive(fe_fs.uniform_lbp_raw, [Img], Vector, name='uLBP_G')
pset.addPrimitive(fe_fs.all_sift_raw, [Img], Vector, name='SIFT_G')
pset.addPrimitive(fe_fs.global_hog_raw, [Img], Vector, name='HOG_G')
pset.addPrimitive(fe_fs.hist_raw, [Img], Vector, name='Hist_G')
pset.addPrimitive(fe_fs.featureEx_raw, [Img], Vector, name='featureEx_G')

pset.addPrimitive(fe_fs.medianf_original, [Img], Img, name='Median_G')
pset.addPrimitive(fe_fs.meanf_original, [Img], Img, name='Mean_G')
pset.addPrimitive(fe_fs.minf_original, [Img], Img, name='Min_G')
pset.addPrimitive(fe_fs.maxf_original, [Img], Img, name='Max_G')
pset.addPrimitive(fe_fs.gau_original, [Img, Int1], Img, name='Gau_G')
pset.addPrimitive(fe_fs.gauD_original, [Img, Int1, Int2, Int2], Img, name='GauD_G')
pset.addPrimitive(fe_fs.laplace_original, [Img], Img, name='Lap_G')
pset.addPrimitive(fe_fs.gaussian_Laplace1_original, [Img], Img, name='LoG1_G')
pset.addPrimitive(fe_fs.gaussian_Laplace2_original, [Img], Img, name='LoG2_G')
pset.addPrimitive(fe_fs.sobelxy_original, [Img], Img, name='Sobel_G')
pset.addPrimitive(fe_fs.sobelx_original, [Img], Img, name='SobelX_G')
pset.addPrimitive(fe_fs.sobely_original, [Img], Img, name='SobelY_G')

# mid level features--feature extraction layer
pset.addPrimitive(fe_fs.uniform_lbp, [Img2], Vector, name='uLBP')
pset.addPrimitive(fe_fs.all_sift, [Img2], Vector, name='SIFT')
pset.addPrimitive(fe_fs.global_hog, [Img2], Vector, name='HOG')
pset.addPrimitive(fe_fs.hist, [Img2], Vector, name='Hist')
pset.addPrimitive(fe_fs.featureEx, [Img2], Vector, name='featureEx')

# the input is detected image region

pset.addPrimitive(fe_fs.medianf, [Img2], Img2, name='Median2')
pset.addPrimitive(fe_fs.meanf, [Img2], Img2, name='Mean2')
pset.addPrimitive(fe_fs.minf, [Img2], Img2, name='Min2')
pset.addPrimitive(fe_fs.maxf, [Img2], Img2, name='Max2')
pset.addPrimitive(fe_fs.gau, [Img2, Int1], Img2, name='Gau2')
pset.addPrimitive(fe_fs.gauD, [Img2, Int1, Int2, Int2], Img2, name='GauD2')
pset.addPrimitive(fe_fs.laplace, [Img2], Img2, name='Lap2')
pset.addPrimitive(fe_fs.gaussian_Laplace1, [Img2], Img2, name='LoG12')
pset.addPrimitive(fe_fs.gaussian_Laplace2, [Img2], Img2, name='LoG22')
pset.addPrimitive(fe_fs.sobelxy, [Img2], Img2, name='Sobel2')
pset.addPrimitive(fe_fs.sobelx, [Img2], Img2, name='SobelX2')
pset.addPrimitive(fe_fs.sobely, [Img2], Img2, name='SobelY2')

pset.addPrimitive(fe_fs.median_raw, [Img1], Img2, name='Median')
pset.addPrimitive(fe_fs.mean_raw, [Img1], Img2, name='Mean')
pset.addPrimitive(fe_fs.min_raw, [Img1], Img2, name='Min')
pset.addPrimitive(fe_fs.max_raw, [Img1], Img2, name='Max')
pset.addPrimitive(fe_fs.gau_raw, [Img1, Int1], Img2, name='Gau')
pset.addPrimitive(fe_fs.gauD_raw, [Img1, Int1, Int2, Int2], Img2, name='GauD')
pset.addPrimitive(fe_fs.laplace_raw, [Img1], Img2, name='Lap')
pset.addPrimitive(fe_fs.gaussian_Laplace1_raw, [Img1], Img2, name='LoG1')
pset.addPrimitive(fe_fs.gaussian_Laplace2_raw, [Img1], Img2, name='LoG2')
pset.addPrimitive(fe_fs.sobelxy_raw, [Img1], Img2, name='Sobel')
pset.addPrimitive(fe_fs.sobelx_raw, [Img1], Img2, name='SobelX')
pset.addPrimitive(fe_fs.sobely_raw, [Img1], Img2, name='SobelY')

# region detection
pset.addPrimitive(fe_fs.regionR, [Img, X, Y, width, height], Img1, name='RegionR')
pset.addPrimitive(fe_fs.regionS, [Img, X, Y, windowSize], Img1, name='RegionS')


# Terminals
pset.renameArguments(ARG0='Image')
pset.addEphemeralConstant('Singma', lambda: random.randint(1, 4), Int1)
pset.addEphemeralConstant('Order', lambda: random.randint(0, 3), Int2)
pset.addEphemeralConstant('Theta', lambda: random.randint(0, 8), Float1)
pset.addEphemeralConstant('Frequency', lambda: random.randint(0, 5), Float2)
pset.addEphemeralConstant('classificationN', lambda: random.randint(1, 4), Int3)

pset.addEphemeralConstant('coordsX', lambda: random.randint(0, h-3), X)
pset.addEphemeralConstant('coordsY', lambda: random.randint(0, w-3), Y)
pset.addEphemeralConstant('windowSize', lambda: random.randint(3, w), windowSize)
pset.addEphemeralConstant('width', lambda: random.randint(3, w), width)
pset.addEphemeralConstant('height', lambda: random.randint(3, h), height)

##
creator.create("FitnessMax", base.Fitness, weights=(1.0,))
creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMax)

toolbox = base.Toolbox()
toolbox.register("expr", gp_restrict.genHalfAndHalfMD, pset=pset, min_=initialMinDepth, max_=initialMaxDepth)
toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)
toolbox.register("compile", gp.compile, pset=pset)
toolbox.register("mapp", map)


def evalTrain(individual):
    try:
        func = toolbox.compile(expr=individual)
        train_tf = []
        train_tf_new = []
        for i in range(0, len(y_train)):
            train_tf.append(numpy.asarray(func(x_train[i, :, :])))
        for j in range(0, len(y_train)):
            train_tf_new.append(train_tf[j][0])
        train_tf_new = numpy.asarray(train_tf_new, dtype=float)
        min_max_scaler = preprocessing.MinMaxScaler()
        train_norm = min_max_scaler.fit_transform(train_tf_new)
        if train_tf[0][1] == 1:
            lsvm = LinearSVC()
            accuracy = round(100 * cross_val_score(lsvm, train_norm, y_train, cv=5).mean(), 2)
        elif train_tf[0][1] == 2:
            rf = RandomForestClassifier()
            accuracy = round(100 * cross_val_score(rf, train_norm, y_train, cv=5).mean(), 2)
        elif train_tf[0][1] == 3:
            lr = LogisticRegression()
            accuracy = round(100 * cross_val_score(lr, train_norm, y_train, cv=5).mean(), 2)
        else:
            erf = ExtraTreesClassifier()
            accuracy = round(100 * cross_val_score(erf, train_norm, y_train, cv=5).mean(), 2)
    except:
        accuracy = 0
    return accuracy,


# genetic operator
toolbox.register("evaluate", evalTrain)
toolbox.register("select", tools.selTournament, tournsize=7)
toolbox.register("selectElitism", tools.selBest)
toolbox.register("mate", gp.cxOnePoint)
toolbox.register("expr_mut", gp_restrict.genFull, min_=0, max_=2)
toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr_mut, pset=pset)
# toolbox.decorate("mate", gp.staticLimit(key=operator.attrgetter("height"), max_value=maxDepth))
# toolbox.decorate("mutate", gp.staticLimit(key=operator.attrgetter("height"), max_value=maxDepth))


def GPMain(randomSeeds):
    random.seed(randomSeeds)
    pop = toolbox.population(population)
    # print('the size of population', len(pop))
    hof = tools.HallOfFame(10)
    log = tools.Logbook()
    stats_fit = tools.Statistics(key=lambda ind: ind.fitness.values)
    stats_size_tree = tools.Statistics(key=len)
    mstats = tools.MultiStatistics(fitness=stats_fit, size_tree=stats_size_tree)
    mstats.register("avg", numpy.mean)
    mstats.register("std", numpy.std)
    mstats.register("min", numpy.min)
    mstats.register("max", numpy.max)
    log.header = ["gen", "nevals"] + mstats.fields
    pop, log, best_ind_gen = evalGP.eaSimple(pop, toolbox, cxProb, mutProb, elitismProb, generation,
                                             stats=mstats, halloffame=hof, verbose=True)
    return pop, log, hof, best_ind_gen


def evalTest(toolbox, individual, trainData, trainLabel, test, testL):
    func = toolbox.compile(expr=individual)
    train_tf = []
    test_tf = []
    train_tf_new = []
    test_tf_new = []
    for i in range(0, len(trainLabel)):
        train_tf.append(numpy.asarray(func(trainData[i, :, :])))
    for j in range(0, len(testL)):
        test_tf.append(numpy.asarray(func(test[j, :, :])))
    for m in range(0, len(trainLabel)):
        train_tf_new.append(train_tf[m][0])
    train_tf_new = numpy.asarray(train_tf_new, dtype=float)
    for n in range(0, len(testL)):
        test_tf_new.append(test_tf[n][0])
    test_tf_new = numpy.asarray(test_tf_new, dtype=float)
    min_max_scaler = preprocessing.MinMaxScaler()
    train_norm = min_max_scaler.fit_transform(train_tf_new)
    test_norm = min_max_scaler.transform(test_tf_new)
    print('test', train_tf[0][1])
    if train_tf[0][1] == 1:
        lsvm = LinearSVC()
        lsvm.fit(train_norm, trainLabel)
        accuracy = round(100 * lsvm.score(test_norm, testL), 2)
    elif train_tf[0][1] == 2:
        rf = RandomForestClassifier()
        rf.fit(train_norm, trainLabel)
        accuracy = round(100 * rf.score(test_norm, testL), 2)
    elif train_tf[0][1] == 3:
        lr = LogisticRegression()
        lr.fit(train_norm, trainLabel)
        accuracy = round(100 * lr.score(test_norm, testL), 2)
    else:
        erf = ExtraTreesClassifier()
        erf.fit(train_norm, trainLabel)
        accuracy = round(100 * erf.score(test_norm, testL), 2)
    return numpy.asarray(train_tf), numpy.asarray(test_tf), trainLabel, testL, accuracy, train_tf[0][1], train_tf[0][0]


def save_individual(filename, individuals):
    with open(str(randomSeeds) + str(filename) + '.pickle', 'wb') as file:
        pickle.dump(individuals, file, protocol=pickle.HIGHEST_PROTOCOL)
    file.close()
    return


if __name__ == "__main__":
    beginTime = time.process_time()
    pop, log, hof, best_ind_gen = GPMain(randomSeeds)
    endTime = time.process_time()
    trainTime = endTime - beginTime
    train_tf, test_tf, trainLabel, testL, testResults, classifier, features  = evalTest(toolbox, hof[0],
                                                                             x_train, y_train, x_test, y_test)
    testTime = time.process_time() - endTime
    bestInd = saveFile.bestInd(toolbox, pop, 5)
    saveFile.saveAllResults_new(randomSeeds, dataSetName, bestInd, log,
                            hof, trainTime, testTime, testResults, classifier, features)
    save_individual('best_individual_gen', best_ind_gen)
    save_individual('the_final_population', pop)
    save_individual('the_best_individual', hof[0])
    print('testResult', testResults)
    print(train_tf.shape, test_tf.shape)
    print(hof[0])
    print('End')
